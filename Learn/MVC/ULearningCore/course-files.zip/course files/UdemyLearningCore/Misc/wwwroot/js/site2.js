﻿// Write your JavaScript code.
console.log('hello');console.log('hello2');